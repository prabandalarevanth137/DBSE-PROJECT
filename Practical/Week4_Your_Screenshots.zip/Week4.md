# Practical 4 -- MongoDB Atlas Bank Transaction Database

## Create Database

**Database Name:** `bankdb`

**Collection Name:** `customers`

**Collection Name:** `transactions`

### Final Structure

``` text
bankdb
│
├── customers
│
└── transactions
```

------------------------------------------------------------------------

## Insert Customer Data

The `customers` collection contains 8 customer records.

### Customer Data Screenshots

![Customers 1](screenshots/customers-1.png)

![Customers 2](screenshots/customers-2.png)

![Customers 3](screenshots/customers-3.png)

![Customers 4](screenshots/customers-4.png)

------------------------------------------------------------------------

## Insert Transaction Data

The `transactions` collection contains 15 transaction records.

### Transaction Data Screenshots

![Transactions 1](screenshots/transactions-1.png)

![Transactions 2](screenshots/transactions-2.png)

![Transactions 3](screenshots/transactions-3.png)

![Transactions 4](screenshots/transactions-4.png)

![Transactions 5](screenshots/transactions-5.png)

![Transactions 6](screenshots/transactions-6.png)

![Transactions 7](screenshots/transactions-7.png)

![Transactions 8](screenshots/transactions-8.png)

------------------------------------------------------------------------

# MongoDB Queries

## Query 1: Display All Customers

**Filter:**

``` json
{}
```

------------------------------------------------------------------------

## Query 2: Find Active Customers

**Filter:**

``` json
{"status":"Active"}
```

------------------------------------------------------------------------

## Query 3: Find Customers With Balance Greater Than 100000

**Filter:**

``` json
{"balance":{"$gt":100000}}
```

------------------------------------------------------------------------

## Query 4: Find Hyderabad Customers

**Filter:**

``` json
{"city":"Hyderabad"}
```

------------------------------------------------------------------------

## Query 5: Find Savings Account Customers

**Filter:**

``` json
{"account_type":"Savings"}
```

------------------------------------------------------------------------

## Query 6: Find Transactions Greater Than 20000

**Filter:**

``` json
{"amount":{"$gt":20000}}
```

------------------------------------------------------------------------

## Query 7: Find Deposits

**Filter:**

``` json
{"type":"Deposit"}
```

------------------------------------------------------------------------

## Query 8: Find ATM Transactions

**Filter:**

``` json
{"mode":"ATM"}
```

------------------------------------------------------------------------

## Query 9: Find Deposits Greater Than 50000

**Filter:**

``` json
{"type":"Deposit","amount":{"$gt":50000}}
```

------------------------------------------------------------------------

## Query 10: Find Hyderabad Customers With High Balance

**Filter:**

``` json
{"city":"Hyderabad","balance":{"$gt":100000}}
```

------------------------------------------------------------------------

## Query 11: Find Customers in Multiple Cities

**Filter:**

``` json
{"city":{"$in":["Hyderabad","Vijayawada","Warangal"]}}
```

------------------------------------------------------------------------

## Query 12: Sort Customers by Balance

**Aggregation:**

``` json
{"$sort":{"balance":-1}}
```

------------------------------------------------------------------------

## Query 13: Calculate Total Transaction Amount

**Aggregation:**

``` json
{
  "$group": {
    "_id": null,
    "total_amount": {
      "$sum": "$amount"
    }
  }
}
```

------------------------------------------------------------------------

## Query 14: Calculate Average Transaction Amount

**Aggregation:**

``` json
{
  "$group": {
    "_id": null,
    "average_amount": {
      "$avg": "$amount"
    }
  }
}
```

------------------------------------------------------------------------

## Query 15: Total Transaction Amount by Type

**Aggregation:**

``` json
{
  "$group": {
    "_id": "$type",
    "total_amount": {
      "$sum": "$amount"
    }
  }
}
```

------------------------------------------------------------------------

## Query 16: Number of Transactions per Customer

**Aggregation:**

``` json
[
  {
    "$group": {
      "_id": "$customer_id",
      "transaction_count": {
        "$sum": 1
      }
    }
  },
  {
    "$sort": {
      "transaction_count": -1
    }
  }
]
```

------------------------------------------------------------------------

## Query 17: Customer + Transaction Join

**Aggregation:**

``` json
{
  "$lookup": {
    "from": "customers",
    "localField": "customer_id",
    "foreignField": "customer_id",
    "as": "customer_details"
  }
}
```

------------------------------------------------------------------------

## Query 18: Display Customer Name and Transaction Amount

**Pipeline:**

``` json
[
  {
    "$lookup": {
      "from": "customers",
      "localField": "customer_id",
      "foreignField": "customer_id",
      "as": "customer"
    }
  },
  {
    "$unwind": "$customer"
  },
  {
    "$project": {
      "_id": 0,
      "transaction_id": 1,
      "customer_name": "$customer.name",
      "city": "$customer.city",
      "type": 1,
      "amount": 1,
      "mode": 1
    }
  }
]
```

------------------------------------------------------------------------

## Query 19: Total Transaction Amount for Each Customer

**Pipeline:**

``` json
[
  {
    "$group": {
      "_id": "$customer_id",
      "total_transaction": {
        "$sum": "$amount"
      }
    }
  },
  {
    "$lookup": {
      "from": "customers",
      "localField": "_id",
      "foreignField": "customer_id",
      "as": "customer"
    }
  },
  {
    "$unwind": "$customer"
  },
  {
    "$project": {
      "_id": 0,
      "customer_id": "$_id",
      "customer_name": "$customer.name",
      "total_transaction": 1
    }
  },
  {
    "$sort": {
      "total_transaction": -1
    }
  }
]
```

------------------------------------------------------------------------

## Query 20: Complex Bank Transaction Report

**Pipeline:**

``` json
[
  {
    "$match": {
      "status": "Active",
      "balance": {
        "$gt": 80000
      }
    }
  },
  {
    "$lookup": {
      "from": "transactions",
      "localField": "customer_id",
      "foreignField": "customer_id",
      "as": "transactions"
    }
  },
  {
    "$unwind": "$transactions"
  },
  {
    "$group": {
      "_id": "$customer_id",
      "customer_name": {
        "$first": "$name"
      },
      "city": {
        "$first": "$city"
      },
      "balance": {
        "$first": "$balance"
      },
      "total_transactions": {
        "$sum": "$transactions.amount"
      },
      "transaction_count": {
        "$sum": 1
      }
    }
  },
  {
    "$sort": {
      "total_transactions": -1
    }
  }
]
```

------------------------------------------------------------------------

## Result

The bank database was successfully created in MongoDB Atlas, customer
and transaction data were inserted, and the required MongoDB queries and
aggregation pipelines were executed.
