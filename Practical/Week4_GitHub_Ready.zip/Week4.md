# Practical 4 -- MongoDB Atlas Bank Transaction Database

## Create Database

**Database Name:** `bankdb`

**Collection Name:** `customers`

**Collection Name:** `transactions`

### Final Structure

``` text
bankdb
│
├── customers
│
└── transactions
```

### Screenshot -- Database Creation

![Database Creation](screenshots/page-01.png)

------------------------------------------------------------------------

## Insert Customer Data

The `customers` collection contains 8 customer records.

### Screenshot -- Customer Data

![Customer Data](screenshots/page-02.png)

------------------------------------------------------------------------

## Insert Transaction Data

The `transactions` collection contains 15 transaction records.

### Screenshot -- Transaction Data

![Transaction Data](screenshots/page-03.png)

------------------------------------------------------------------------

# MongoDB Queries

## Query 2: Find Active Customers

**Filter:**

``` json
{"status":"Active"}
```

![Query 2](screenshots/page-04.png)

------------------------------------------------------------------------

## Query 3: Find Customers With Balance Greater Than 100000

**Filter:**

``` json
{"balance":{"$gt":100000}}
```

![Query 3](screenshots/page-05.png)

------------------------------------------------------------------------

## Query 4: Find Hyderabad Customers

**Filter:**

``` json
{"city":"Hyderabad"}
```

![Query 4](screenshots/page-06.png)

------------------------------------------------------------------------

## Query 5: Find Savings Account Customers

**Filter:**

``` json
{"account_type":"Savings"}
```

![Query 5](screenshots/page-07.png)

------------------------------------------------------------------------

## Query 6: Find Transactions Greater Than 20000

**Filter:**

``` json
{"amount":{"$gt":20000}}
```

![Query 6](screenshots/page-08.png)

------------------------------------------------------------------------

## Query 7: Find Deposits

**Filter:**

``` json
{"type":"Deposit"}
```

![Query 7](screenshots/page-09.png)

------------------------------------------------------------------------

## Query 8: Find ATM Transactions

**Filter:**

``` json
{"mode":"ATM"}
```

![Query 8](screenshots/page-10.png)

------------------------------------------------------------------------

## Query 9: Find Deposits Greater Than 50000

**Filter:**

``` json
{"type":"Deposit","amount":{"$gt":50000}}
```

![Query 9](screenshots/page-11.png)

------------------------------------------------------------------------

## Query 10: Find Hyderabad Customers With High Balance

**Filter:**

``` json
{"city":"Hyderabad","balance":{"$gt":100000}}
```

![Query 10](screenshots/page-12.png)

------------------------------------------------------------------------

## Query 11: Find Customers in Multiple Cities

**Filter:**

``` json
{"city":{"$in":["Hyderabad","Vijayawada","Warangal"]}}
```

![Query 11](screenshots/page-13.png)

------------------------------------------------------------------------

## Query 12: Sort Customers by Balance

**Aggregation:**

``` json
{"$sort":{"balance":-1}}
```

![Query 12](screenshots/page-14.png)

------------------------------------------------------------------------

## Query 13: Calculate Total Transaction Amount

**Aggregation:**

``` json
{
  "$group": {
    "_id": null,
    "total_amount": {
      "$sum": "balance"
    }
  }
}
```

![Query 13](screenshots/page-15.png)

------------------------------------------------------------------------

## Query 14: Calculate Average Transaction Amount

**Aggregation:**

``` json
{
  "$group": {
    "_id": null,
    "average_amount": {
      "$avg": "balance"
    }
  }
}
```

![Query 14](screenshots/page-16.png)

------------------------------------------------------------------------

## Query 15: Total Transaction Amount by Type

**Aggregation:**

``` json
[
  {
    "$group": {
      "_id": "$type",
      "total_amount": {
        "$sum": "amount"
      }
    }
  }
]
```

![Query 15](screenshots/page-17.png)

------------------------------------------------------------------------

## Query 16: Number of Transactions per Customer

**Aggregation:**

``` json
[
  {
    "$group": {
      "_id": "$customer_id",
      "transaction_count": {
        "$sum": 1
      }
    }
  },
  {
    "$sort": {
      "transaction_count": -1
    }
  }
]
```

![Query 16](screenshots/page-18.png)

------------------------------------------------------------------------

## Query 17: Customer + Transaction Join

**Aggregation:**

``` json
{
  "$lookup": {
    "from": "customers",
    "localField": "customer_id",
    "foreignField": "customer_id",
    "as": "customer_details"
  }
}
```

![Query 17](screenshots/page-19.png)

------------------------------------------------------------------------

## Query 18: Display Customer Name and Transaction Amount

**Pipeline:**

``` json
[
  {
    "$lookup": {
      "from": "customers",
      "localField": "customer_id",
      "foreignField": "customer_id",
      "as": "customer"
    }
  },
  {
    "$unwind": "$customer"
  },
  {
    "$project": {
      "_id": 0,
      "transaction_id": 1,
      "customer_name": "$customer.name",
      "city": "$customer.city",
      "type": 1,
      "amount": 1,
      "mode": 1
    }
  }
]
```

![Query 18](screenshots/page-21.png)

------------------------------------------------------------------------

## Query 19: Total Transaction Amount for Each Customer

**Pipeline:**

``` json
[
  {
    "$group": {
      "_id": "$customer_id",
      "total_transaction": {
        "$sum": "$amount"
      }
    }
  },
  {
    "$lookup": {
      "from": "customers",
      "localField": "_id",
      "foreignField": "customer_id",
      "as": "customer"
    }
  },
  {
    "$unwind": "$customer"
  },
  {
    "$project": {
      "_id": 0,
      "customer_id": "$_id",
      "customer_name": "$customer.name",
      "total_transaction": 1
    }
  },
  {
    "$sort": {
      "total_transaction": -1
    }
  }
]
```

![Query 19](screenshots/page-22.png)

------------------------------------------------------------------------

## Query 20: Complex Bank Transaction Report

**Pipeline:**

``` json
[
  {
    "$match": {
      "status": "Active",
      "balance": {
        "$gt": 80000
      }
    }
  },
  {
    "$lookup": {
      "from": "transactions",
      "localField": "customer_id",
      "foreignField": "customer_id",
      "as": "transactions"
    }
  },
  {
    "$unwind": "$transactions"
  },
  {
    "$group": {
      "_id": "$customer_id",
      "customer_name": {
        "$first": "$name"
      },
      "city": {
        "$first": "$city"
      },
      "balance": {
        "$first": "$balance"
      },
      "total_transactions": {
        "$sum": "$transactions.amount"
      },
      "transaction_count": {
        "$sum": 1
      }
    }
  },
  {
    "$sort": {
      "total_transactions": -1
    }
  }
]
```

![Query 20](screenshots/page-24.png)

------------------------------------------------------------------------

## Result

The bank database was successfully created in MongoDB Atlas, customer
and transaction data were inserted, and the required MongoDB queries and
aggregation pipelines were executed.
